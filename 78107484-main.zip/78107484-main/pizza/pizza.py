import sys
from tabulate import tabulate
import csv

if len(sys.argv) < 2:
    sys.exit("Too few command-line arguments")
elif len(sys.argv) > 2:
    sys.exit("Too many command-line arguments")
elif sys.argv[1].split(".")[1] != "csv":
    sys.exit("Not a csv file")
else:
    try:
        pizzas = []
        with open(sys.argv[1]) as file:
                reader = csv.reader(file)
                for row in reader:
                    pizzas.append([row[0], row[1], row[2]])
        print(tabulate(pizzas[1:], headers=pizzas[0], tablefmt="grid"))

    except FileNotFoundError:
        sys.exit("File does not exist")
