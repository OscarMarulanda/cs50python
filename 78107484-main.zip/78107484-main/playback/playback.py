def playback():
    statement = (input("enter your statement")).replace(" ", "...")
    print(statement)

playback()
