a = input("enter arithmetic expression: ")

x = int(a.split(" ")[0])
y = a.split(" ")[1]
z = int(a.split(" ")[2])

match y:
    case "+":
        print(float(x + z))
    case "-":
        print(float(x - z))
    case "*":
        print(float(x * z))
    case "/":
        print(float(x / z))
