x = input()
y = input()

if x<y:
    print(x, " is less than ", y)
elif x==y:
    print (x, "is equal to", y)
else:
    print(y, "is less than", x)
