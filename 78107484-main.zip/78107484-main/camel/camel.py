x = input("enter variable name in camel case: ")
for a in x:
    if a.isupper():
        x = x[:x.find(a)] + "_" + x[x.find(a):]

print(x.lower())

