import re
months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December"
]

def outdate():
    while True:
        date1 = input("enter date in month-day-year format like 9/8/1636 or September 8, 1636").strip()
        date = date1.replace(",", "")

        datenew = re.split('/| ', date)

        if "/" in date:
            if datenew[0] in months:
                continue
        if "," not in date1 and "/" not in date1:
            continue
        if datenew[0].title() in months:
            datenew[0] = months.index(datenew[0].title())+1
        if datenew[1].title() in months:
            continue
        if int(datenew[1]) > 31:
            continue
        if int(datenew[0]) > 12:
            continue

        else:
            print(datenew[2]+"-"+str(datenew[0]).zfill(2)+"-"+str(datenew[1]).zfill(2))
            return
outdate()
