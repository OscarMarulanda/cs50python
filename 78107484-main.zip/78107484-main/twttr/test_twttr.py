from twttr import shorten

def test_word():
    assert shorten("Oscar") == "scr"


