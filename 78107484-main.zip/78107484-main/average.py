import statistics

print(statistics.mean([0, 10]))
