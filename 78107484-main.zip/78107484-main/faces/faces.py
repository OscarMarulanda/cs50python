import emoji
def convert(str):
    return str.replace(":)", emoji.emojize(":slightly_smiling_face:")).replace(":(", emoji.emojize(":slightly_frowning_face:"))

def main():
    phrase = input("enter the phrase to be emojized: ")
    print(convert(phrase))

main()

