coin = 0

while True:
    if coin < 50:
        print("Amount Due:" , 50-coin )
    else:
        change = coin - 50
        print("Change Owed:", change)
        break
    new_coin = int(input("Insert Coin: "))
    if new_coin != 5 and new_coin != 10 and new_coin != 25:
          continue
    else:
        coin = coin + new_coin



