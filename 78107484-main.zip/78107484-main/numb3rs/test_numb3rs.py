from numb3rs import validate

def test_numb3rs():
    assert validate("255.2.2.2") == True
    assert validate("cat") == False
    assert validate("275.2.2.2") == False
    assert validate("512.512.512.512") == False
    assert validate("255.255.255.255") == True
    assert validate("75.456.76.65") == False
