from sympy import symbols, solve

x = symbols('x')
expr = x-4-2


sol = solve(expr)


sol
