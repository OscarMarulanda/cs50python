print(type(dict()))
