greeting = input("enter greeting").strip().lower()

if "hello" in greeting.split()[0]:
    print("$0")
elif greeting[0] == "h":
    print("$20")
else:
    print("$100")
