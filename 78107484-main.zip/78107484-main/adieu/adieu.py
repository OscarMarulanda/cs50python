import inflect


p = inflect.engine()

farewell = "Adieu, adieu, to"


mylist = []
while True:
    try:

        new_name = input("Name: ")
        mylist.append(new_name)
        joint_list = p.join((mylist))

    except EOFError:
        print(farewell, joint_list)
        exit()


