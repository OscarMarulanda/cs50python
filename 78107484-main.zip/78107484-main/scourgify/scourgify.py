import csv
import sys

if len(sys.argv) < 3:
    sys.exit("Too few command-line arguments")
elif len(sys.argv) > 3:
    sys.exit("Too many command-line arguments")
elif sys.argv[1].split(".")[1] != "csv":
    sys.exit("Not a csv file")
elif sys.argv[2].split(".")[1] != "csv":
    sys.exit("Not a csv file")
else:
    try:
        students = []
        with open(sys.argv[1]) as file:
                reader = csv.DictReader(file)
                with open(sys.argv[2], "w") as file2:
                    writer = csv.DictWriter(file2, fieldnames=["first", "last", "house"])
                    writer.writeheader()
                    for row in reader:
                        last, first = row["name"].split(", ")
                        row["first"] = first_name
                        row["last"] = last_name
                        writer.writerow(row)

    except FileNotFoundError:
        sys.exit("File does not exist")
