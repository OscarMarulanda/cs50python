from validator_collection import validators, checkers, errors

def validate_email(value):
    try:
        if validators.email(value, allow_empty = False):
            print("Valid")
    except errors.InvalidEmailError:
        print("Invalid")
    except ValueError:
        print("Invalid")



validate_email(input("What's your email address? "))
