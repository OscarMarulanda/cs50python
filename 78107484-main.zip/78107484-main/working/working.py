import re
import sys


def main():
    print(convert(input("Hours: ")))


def convert(s):
    if re.search(r"([0-9][0-2]*:*([0-5][0-9])* [AP]M) to ([0-9][0-2]*:*([0-5][0-9])* [AP]M)", s):
        hour = re.search(r"([0-9][0-2]*:*([0-5][0-9])* [AP]M) to ([0-9][0-2]*:*([0-5][0-9])* [AP]M)", s)
        hour_split =  hour.groups()

        a = []

        result = list(hour_split)

        if result[1] == None:
            for time in [result[0], result[2]]:
                if "PM" in time:
                    if time.split(" ")[0] != "12":
                        a.append(str(int(time.split(" ")[0])+12)+":"+ "00")
                    else:
                        a.append("12:00")
                else:
                    if time.split(" ")[0] == "12":
                        a.append("00:00")
                    d=time.split(" ")[0]
                    a.append(f"{int(d):02}" + ":" + "00")

        else:
            for time in [result[0], result[2]]:
                if "PM" in time:
                    if time.split(":")[0] != "12":
                        a.append(str(int(time.split(":")[0])+12)+":"+time.split(":")[1].replace(" PM", ""))
                    else:
                        a.append("12"+":"+time.split(":")[1].replace(" PM", ""))
                else:
                    if time.split(":")[0] == "12":
                        a.append("00"+":"+time.split(":")[1].replace(" AM", ""))
                    d=time.split(":")[0]
                    a.append(f"{int(d):02}" + ":" + time.split(":")[1].replace(" AM", ""))

        return a[0] + " to " + a[1]

    else:
        raise ValueError


if __name__ == "__main__":
    main()
