from seasons import check_birthday

def main():
    test_check_birthday()

def test_check_birthday():
    assert check_birthday("1992-10-06") == ("1992", "10", "06")
    assert check_birthday("1992-1-2") == None
    assert check_birthday("July-02-1992") == None

if __name__ == "__main__":
    main()
