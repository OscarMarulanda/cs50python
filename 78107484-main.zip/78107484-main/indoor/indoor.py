def lowerVoice():
    user = input("enter your string: ").lower()
    print(user)

lowerVoice()
