


def grocery():
    lista = {}
    while True:
        try:
            item = input()
            if item in lista:
                lista[item] += 1
            else:
                lista[item] = 1
        except EOFError:
            myKeys = list(lista.keys())
            myKeys.sort()
            sorted_list = {i: lista[i] for i in myKeys}
            for keys, value in sorted_list.items():
                print(value, keys.upper())
            exit()
grocery()




