import emoji
text = input("Input")

print(emoji.emojize(text, language="alias"))
