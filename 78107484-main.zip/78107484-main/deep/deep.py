x =  input("what is the answer?").lower().strip()
match x:
    case "42" | "forty two" | "forty-two":
        print("Yes")
    case _:
        print("No")
