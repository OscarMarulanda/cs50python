import random


while True:
    try:
        level = int(input("Level: "))
        if level <= 0:
            continue
        rango = random.randint(0,level)
        break
    except ValueError:
        continue

while True:
    try:
        guess = int(input("Guess: "))
        if guess <1:
            continue
        if guess < rango:
            print("Too small!")
            continue
        elif guess > rango:
            print ("Too large!")
            continue
        else:
            print("Just right!")
            break
    except ValueError:
        continue
