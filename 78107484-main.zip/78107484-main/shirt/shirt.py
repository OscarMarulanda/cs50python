import csv
import sys
from PIL import Image, ImageDraw, ImageFilter, ImageOps
import PIL

if len(sys.argv) < 3:
    sys.exit("Too few command-line arguments")
elif len(sys.argv) > 3:
    sys.exit("Too many command-line arguments")
elif sys.argv[1].split(".")[1] not in ["jpg", "jpeg", "png"]:
    sys.exit("Not a valid file")
elif sys.argv[2].split(".")[1] not in ["jpg", "jpeg", "png"]:
    sys.exit("Not a valid file")
elif sys.argv[2].split(".")[1] != sys.argv[1].split(".")[1]:
    sys.exit("different extensions")

shirt = Image.open("shirt.png")
size = shirt.size
before = Image.open(sys.argv[1])
before = ImageOps.fit(before, size)
before.paste(shirt, shirt)


before.save(sys.argv[2])

