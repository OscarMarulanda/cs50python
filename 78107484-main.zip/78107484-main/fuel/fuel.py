
def main():
    while True:
        fraction = input("Fraction:").split("/")
        frac = int(fraction[0]) / int(fraction[1])
        if frac > 1:
            continue
        print(gauge(convert(frac)))
        break


def convert(frac):
    while True:
        try:
            return frac
        except ValueError:
            raise ValueError
        except ZeroDivisionError:
            raise ZeroDivisionError
        except IndexError:
            raise IndexError

def gauge(percentage):
    if percentage >= 0.99:
        return("F")
    elif percentage <= 0.01:
        return("E")
    else:
        return "{:.0%}".format(percentage)


if __name__ == "__main__":
    main()
