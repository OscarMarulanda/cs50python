def main():
    word = input("Enter string of text:")
    shorten(word)

def shorten(word):

    for a in word:
        if a.lower() in "aeiou":
            word = word.replace(a, "")
    return word

if __name__ == "__main__":
    main()
