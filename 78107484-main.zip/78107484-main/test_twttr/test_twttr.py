from twttr import shorten

def test_word():
    assert shorten("Oscar") == "scr"
    assert shorten("twitter") == "twttr"
    assert shorten("AExIOU") == "x"
    assert shorten("1234") == "1234"
    assert shorten(".,!@?") == ".,!@?"
