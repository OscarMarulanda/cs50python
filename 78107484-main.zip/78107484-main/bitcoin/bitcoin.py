import requests
import sys
import json


response = requests.get("https://api.coindesk.com/v1/bpi/currentprice.json")

json_file = response.json()

rate = float((json_file['bpi']['USD']['rate']).replace(",", ""))


try:
    if len(sys.argv) < 2:
        sys.exit("Missing command-line argument")
    elif len(sys.argv) > 2:
        print("Too many arguments")
    else:
        price = rate * float(sys.argv[1])
        print(f"${price:,.4f}")
except ValueError:
    sys.exit("Command-line argument is not a number")

