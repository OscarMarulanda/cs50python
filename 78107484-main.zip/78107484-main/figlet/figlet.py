import sys
import pyfiglet
import random
from pyfiglet import Figlet

figlet = Figlet()

if len(sys.argv) == 3:
    if sys.argv[2] not in figlet.getFonts():
       sys.exit("error, font not found")
    elif sys.argv[1] != "-f" and sys.argv[1]!= "--font":
        sys.exit("error, no font specified")
    else:
      text = input("enter string: ")
      print(pyfiglet.figlet_format(text, font=sys.argv[2]))
elif len(sys.argv) == 1:
   text = input("enter string: ")
   print(pyfiglet.figlet_format(text, font=random.choice(figlet.getFonts())))
else:
    sys.exit("invalid number of arguments")

