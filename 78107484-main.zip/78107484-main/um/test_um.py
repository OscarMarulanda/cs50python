import pytest
from um import count

def test_um():
    assert count("um") == 1
    assert count("UM") == 1
    assert count("trum") == 0
