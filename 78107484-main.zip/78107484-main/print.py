print(type(50))
print(type("hi"))
