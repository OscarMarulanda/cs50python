x = 0
while x < 100:
    #if x%3 == 0:
        print(x)
        
    x += 1
