def main():
    plate = input("Plate: ")
    if is_valid(plate):
        print("Valid")
    else:
        print("Invalid")


def is_valid(s):
    if length(s):
        if first_two_letters(s):
            if check_numbers(s):
                if alph_num(s):
                    return True




def length(string):
    if 2 <= int(len(string)) <= 6:
        return True
    else:
        return False

def first_two_letters(f2l):
    if f2l[0:2].isalpha():
        return True
    else:
        return False

def check_numbers(nums):
    for x in nums:
        if x.isalpha() == False:
            if x == "0":
                return False
            else:
                for y in nums[nums.find(x):]:
                    if y.isalpha():
                        return False
            return True
    return True

def alph_num(plate):
    for b in plate:
        if b.isalnum() == False:
            return False
    return True

main()
