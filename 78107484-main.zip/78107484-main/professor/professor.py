import random

def main():
    print("Score:", generate_integer(get_level()))

def get_level():
    while True:
        try:
            level = int(input("Level: "))
            if level <1 or level > 3:
                continue
            return level
        except ValueError:
            continue


def generate_integer(level):
    count = 0
    points = 0
    while True:
        try:
            while count < 10:
                count += 1
                match level:
                    case 1:
                       x = random.randint(0, (10**level)-1)
                       y = random.randint(0, (10**level)-1)
                    case 2:
                        x = random.randint(10, (10**level)-1)
                        y = random.randint(10, (10**level)-1)
                    case 3:
                        x = random.randint(100, (10**level)-1)
                        y = random.randint(100, (10**level)-1)
                tries=0
                while True:
                    try:
                        result = input(f"{x} + {y} = ")
                        if result != str(x+y):
                            tries += 1
                            print("EEE")
                            if tries == 3:
                                print(f"{x} + {y} =",x+y)
                                break
                            continue
                        else:
                            points += 1
                            break
                    except ValueError:
                        raise ValueError("EEE")

            return points
        except ValueError:
            continue

if __name__ == "__main__":
    main()
