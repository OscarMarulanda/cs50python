def main():
    x = input("enter time: ")
    if 7<= convert(x) <= 8:
        print("breakfast time")
    elif 12 <= convert(x) <= 13:
        print("lunch time")
    elif 18<= convert(x) <= 19:
        print("dinner time")


def convert(time):
    hour = time.split(":")
    return (int(hour[0])+(int(hour[1])/60))


if __name__ == "__main__":
    main()
