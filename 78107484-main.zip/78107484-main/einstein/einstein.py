def emc2():
    mass = int(input("enter the mass in kg as an integer: "))
    print(mass*(300000000*300000000))
emc2()

